CREATE TABLE IF NOT EXISTS `wptz_gf_addon_feed` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `meta` longtext COLLATE utf8mb4_unicode_ci,
  `addon_slug` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addon_form` (`addon_slug`,`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wptz_gf_addon_feed`;
 
INSERT INTO `wptz_gf_addon_feed` VALUES ('1', '1', '1', '{"feedName":"Home page pre launch invitation button","mailchimpList":"ded1c6630c","mappedFields_EMAIL":"3","mappedFields_FNAME":"1","mappedFields_LNAME":"id","mc_group_56838de27bbd3619247092_enabled":"1","mc_group_56838de27bbd3619247092_decision":"if","mc_group_56838de27bbd3619247092_field_id":"4","mc_group_56838de27bbd3619247092_operator":"is","mc_group_56838de27bbd3619247092_value":"1","feed_condition_conditional_logic":"0","feed_condition_conditional_logic_object":[],"double_optin":"0","sendWelcomeEmail":"0"}', 'gravityformsmailchimp');
# --------------------------------------------------------

