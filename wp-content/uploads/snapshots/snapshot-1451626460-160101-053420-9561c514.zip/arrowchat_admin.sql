CREATE TABLE IF NOT EXISTS `arrowchat_admin` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `arrowchat_admin`;
 
INSERT INTO `arrowchat_admin` VALUES ('1', 'admin@scb', 'f9c1aa1306bb03116a2b7c198fa7fe77', 'scott@CirculoCristiano.com');
# --------------------------------------------------------

