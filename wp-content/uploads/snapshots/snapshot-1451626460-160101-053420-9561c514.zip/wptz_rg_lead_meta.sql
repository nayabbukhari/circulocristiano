CREATE TABLE IF NOT EXISTS `wptz_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `lead_id` (`lead_id`),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wptz_rg_lead_meta`;
 
INSERT INTO `wptz_rg_lead_meta` VALUES ('1', '1', '3', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('2', '1', '3', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('3', '1', '4', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('4', '1', '4', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('5', '1', '5', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('6', '1', '5', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('7', '1', '6', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('8', '1', '6', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('9', '1', '7', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('10', '1', '7', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('11', '1', '8', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('12', '1', '8', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('13', '1', '9', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('14', '1', '9', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('15', '1', '10', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('16', '1', '10', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('17', '1', '11', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('18', '1', '11', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('19', '1', '12', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('20', '1', '12', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('21', '1', '13', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('22', '1', '13', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('23', '1', '14', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('24', '1', '14', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('25', '1', '15', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('26', '1', '15', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('27', '1', '16', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('28', '1', '16', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('29', '1', '17', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('30', '1', '17', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('31', '1', '18', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('32', '1', '18', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('33', '1', '19', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('34', '1', '19', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('35', '1', '20', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('36', '1', '20', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('37', '1', '21', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('38', '1', '21', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('39', '1', '22', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('40', '1', '22', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('41', '1', '23', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('42', '1', '23', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('43', '1', '24', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('44', '1', '24', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('45', '1', '25', 'gravityformsmailchimp_is_fulfilled', '1'); 
INSERT INTO `wptz_rg_lead_meta` VALUES ('46', '1', '25', 'processed_feeds', 'a:1:{s:21:"gravityformsmailchimp";a:1:{i:0;s:1:"1";}}');
# --------------------------------------------------------

