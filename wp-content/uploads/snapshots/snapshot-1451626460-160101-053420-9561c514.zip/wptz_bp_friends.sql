CREATE TABLE IF NOT EXISTS `wptz_bp_friends` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `initiator_user_id` bigint(20) NOT NULL,
  `friend_user_id` bigint(20) NOT NULL,
  `is_confirmed` tinyint(1) DEFAULT '0',
  `is_limited` tinyint(1) DEFAULT '0',
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `initiator_user_id` (`initiator_user_id`),
  KEY `friend_user_id` (`friend_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
TRUNCATE TABLE `wptz_bp_friends`;
 
INSERT INTO `wptz_bp_friends` VALUES ('1', '1', '3', '0', '0', '2016-01-01 03:55:46');
# --------------------------------------------------------

