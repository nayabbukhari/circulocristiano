CREATE TABLE IF NOT EXISTS `wptz_comment_archive` (
  `comment_archive_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) DEFAULT NULL,
  `comment_id` bigint(20) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `comment_author_user_id` bigint(20) DEFAULT NULL,
  `comment_author_email` varchar(255) DEFAULT NULL,
  `comment_author_ip` varchar(255) DEFAULT NULL,
  `comment_author_url` varchar(255) DEFAULT NULL,
  `comment_content` text,
  `comment_stamp` varchar(255) DEFAULT NULL,
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`comment_archive_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_comment_archive`;
 
INSERT INTO `wptz_comment_archive` VALUES ('1', '1', '3', '285', '6', 'franklin@circuloCristiano.com', '162.17.126.1', '', 'Where does this comment go to? Is this in response to the library-picture attached?', '1450903123', '2015-12-23 12:38:43', '2015-12-23 20:38:43'); 
INSERT INTO `wptz_comment_archive` VALUES ('2', '1', '4', '295', '6', 'franklin@circuloCristiano.com', '162.17.126.1', '', 'This comment area is for what section??', '1450904240', '2015-12-23 12:57:20', '2015-12-23 20:57:20'); 
INSERT INTO `wptz_comment_archive` VALUES ('3', '1', '6', '285', '1', 'scottb50@circulocristiano.com', '72.193.90.170', '', 'it is.', '1451256490', '2015-12-27 14:48:10', '2015-12-27 22:48:10');
# --------------------------------------------------------

