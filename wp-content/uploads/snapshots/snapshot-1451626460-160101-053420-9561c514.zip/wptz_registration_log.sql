CREATE TABLE IF NOT EXISTS `wptz_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL DEFAULT '',
  `IP` varchar(30) NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_registration_log`;
 
INSERT INTO `wptz_registration_log` VALUES ('1', 'Scott@CirculoCristiano.com', '72.193.90.170', '2', '2015-12-13 22:28:19'); 
INSERT INTO `wptz_registration_log` VALUES ('2', 'Scott@CirculoCristiano.com', '72.193.90.170', '3', '2015-12-26 20:24:01');
# --------------------------------------------------------

