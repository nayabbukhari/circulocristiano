CREATE TABLE IF NOT EXISTS `wptz_moderation_reports` (
  `report_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_blog_ID` int(11) NOT NULL DEFAULT '0',
  `report_object_type` varchar(255) DEFAULT NULL,
  `report_object_ID` int(11) NOT NULL DEFAULT '0',
  `report_reason` varchar(255) DEFAULT NULL,
  `report_note` text,
  `report_user_ID` int(11) NOT NULL DEFAULT '0',
  `report_user_email` varchar(255) DEFAULT NULL,
  `report_user_IP` varchar(100) DEFAULT NULL,
  `report_stamp` varchar(255) DEFAULT NULL,
  `report_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `report_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `report_status` varchar(20) NOT NULL DEFAULT 'new',
  PRIMARY KEY (`report_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_moderation_reports`;

# --------------------------------------------------------

