CREATE TABLE IF NOT EXISTS `wptz_bp_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `component` varchar(75) NOT NULL,
  `type` varchar(75) NOT NULL,
  `action` text NOT NULL,
  `content` longtext NOT NULL,
  `primary_link` text NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `date_recorded` datetime NOT NULL,
  `hide_sitewide` tinyint(1) DEFAULT '0',
  `mptt_left` int(11) NOT NULL DEFAULT '0',
  `mptt_right` int(11) NOT NULL DEFAULT '0',
  `is_spam` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_recorded` (`date_recorded`),
  KEY `user_id` (`user_id`),
  KEY `item_id` (`item_id`),
  KEY `secondary_item_id` (`secondary_item_id`),
  KEY `component` (`component`),
  KEY `type` (`type`),
  KEY `mptt_left` (`mptt_left`),
  KEY `mptt_right` (`mptt_right`),
  KEY `hide_sitewide` (`hide_sitewide`),
  KEY `is_spam` (`is_spam`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4;
TRUNCATE TABLE `wptz_bp_activity`;
 
INSERT INTO `wptz_bp_activity` VALUES ('3', '2', 'xprofile', 'updated_profile', '<a href="http://circulocristiano.com/members/adminajay/profile/">Ajay Sharma</a>\'s profile was updated', '', 'http://circulocristiano.com/members/adminajay/profile/', '0', '0', '2015-12-12 15:53:53', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('7', '6', 'activity', 'activity_update', '<a href="http://circulocristiano.com/members/franklinmercedes/" title="franklinmercedes">franklinmercedes</a> posted an update', 'Hola all!', 'http://circulocristiano.com/members/franklinmercedes/', '0', '0', '2015-12-15 19:49:20', '0', '1', '4', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('8', '6', 'activity', 'activity_comment', '<a href="http://circulocristiano.com/members/franklinmercedes/" title="franklinmercedes">franklinmercedes</a> posted a new activity comment', 'comments here.', 'http://circulocristiano.com/members/franklinmercedes/', '7', '7', '2015-12-15 19:49:51', '0', '2', '3', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('11', '6', 'activity', 'activity_update', '<a href="http://circulocristiano.com/members/franklinmercedes/" title="Franklin Mercedes">Franklin Mercedes</a> posted an update', 'This is a glorious day,', 'http://circulocristiano.com/members/franklinmercedes/', '0', '0', '2015-12-19 15:51:14', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('12', '1', 'groups', 'activity_update', '<a href="http://circulocristiano.com/members/admin@scb/" title="admin@scb">admin@scb</a> posted an update in the group <a href="http://circulocristiano.com/groups/test-group-public/">Test group public</a>', 'Welcome to the test group.  Please join.', 'http://circulocristiano.com/members/admin@scb/', '1', '0', '2015-12-21 21:56:16', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('13', '6', 'activity', 'activity_update', '<a href="http://circulocristiano.com/members/franklinmercedes/" title="Franklin Mercedes">Franklin Mercedes</a> posted an update', 'I am starting a food drive for Haiti. Go to our church site and partipate.', 'http://circulocristiano.com/members/franklinmercedes/', '0', '0', '2015-12-23 21:35:04', '0', '1', '8', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('14', '6', 'activity', 'activity_comment', '<a href="http://circulocristiano.com/members/franklinmercedes/" title="Franklin Mercedes">Franklin Mercedes</a> posted a new activity comment', 'I am with you brother franklin . ', 'http://circulocristiano.com/members/franklinmercedes/', '13', '13', '2015-12-23 21:47:43', '0', '2', '3', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('15', '6', 'activity', 'activity_comment', '<a href="http://circulocristiano.com/members/franklinmercedes/" title="Franklin Mercedes">Franklin Mercedes</a> posted a new activity comment', 'fuck mierda culero', 'http://circulocristiano.com/members/franklinmercedes/', '13', '13', '2015-12-23 21:48:08', '0', '4', '7', '1'); 
INSERT INTO `wptz_bp_activity` VALUES ('19', '6', 'activity', 'activity_update', '<a href="http://circulocristiano.com/members/franklinmercedes/" title="Franklin Mercedes">Franklin Mercedes</a> posted an update', 'good christmas cheer', 'http://circulocristiano.com/members/franklinmercedes/', '0', '0', '2015-12-24 21:58:12', '0', '1', '6', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('20', '2', 'activity', 'activity_comment', '<a href="http://circulocristiano.com/members/adminajay/" title="Ajay Sharma">Ajay Sharma</a> posted a new activity comment', 'test agna for --- word ajay', 'http://circulocristiano.com/members/adminajay/', '13', '15', '2015-12-25 08:33:22', '0', '5', '6', '1'); 
INSERT INTO `wptz_bp_activity` VALUES ('21', '2', 'activity', 'activity_comment', '<a href="http://circulocristiano.com/members/adminajay/" title="Ajay Sharma">Ajay Sharma</a> posted a new activity comment', ' Merry Christmas', 'http://circulocristiano.com/members/adminajay/', '19', '19', '2015-12-25 09:45:40', '0', '2', '5', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('22', '6', 'activity', 'activity_comment', '<a href="http://circulocristiano.com/members/franklinmercedes/" title="Franklin Mercedes">Franklin Mercedes</a> posted a new activity comment', 'Thank you. ', 'http://circulocristiano.com/members/franklinmercedes/', '19', '21', '2015-12-25 23:32:09', '0', '3', '4', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('23', '11', 'activity', 'activity_update', '<a href="http://circulocristiano.com/members/scott/" title="scott">scott</a> posted an update', 'hello there.', 'http://circulocristiano.com/members/scott/', '0', '0', '2015-12-26 07:45:35', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('29', '6', 'activity', 'activity_update', '<a href="http://circulocristiano.com/members/franklinmercedes/" title="Franklin Mercedes">Franklin Mercedes</a> posted an update', 'mierda', 'http://circulocristiano.com/members/franklinmercedes/', '0', '0', '2015-12-27 15:44:18', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('32', '18', 'activity', 'activity_update', '<a href="http://circulocristiano.com/members/lunes/" title="lunes">lunes</a> posted an update', 'mierda ostia puta', 'http://circulocristiano.com/members/lunes/', '0', '0', '2015-12-28 00:06:24', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('37', '1', 'activity', 'activity_update', '<a href="http://circulocristiano.com/members/adminscb/" title="admin@scb">admin@scb</a> posted an update', 'Hola.', 'http://circulocristiano.com/members/adminscb/', '0', '0', '2015-12-30 09:55:36', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('42', '1', 'members', 'last_activity', '', '', '', '0', '', '2016-01-01 03:55:23', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('43', '2', 'members', 'last_activity', '', '', '', '0', '', '2016-01-01 02:49:38', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('44', '3', 'members', 'last_activity', '', '', '', '0', '', '2015-12-31 12:14:08', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('45', '4', 'members', 'last_activity', '', '', '', '0', '', '2016-01-01 03:44:55', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('46', '6', 'members', 'last_activity', '', '', '', '0', '', '2015-12-31 16:02:24', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('47', '7', 'members', 'last_activity', '', '', '', '0', '', '2015-12-20 15:14:53', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('48', '8', 'members', 'last_activity', '', '', '', '0', '', '2015-12-18 08:19:27', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('49', '11', 'members', 'last_activity', '', '', '', '0', '', '2015-12-26 07:45:11', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('50', '12', 'members', 'last_activity', '', '', '', '0', '', '2015-12-27 04:46:01', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('51', '16', 'members', 'last_activity', '', '', '', '0', '', '2015-12-27 13:32:13', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('52', '17', 'members', 'last_activity', '', '', '', '0', '', '2015-12-27 21:49:51', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('53', '18', 'members', 'last_activity', '', '', '', '0', '', '2015-12-28 00:04:47', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('54', '19', 'members', 'last_activity', '', '', '', '0', '', '2015-12-29 19:56:50', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('55', '20', 'members', 'last_activity', '', '', '', '0', '', '2015-12-28 12:49:11', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('56', '21', 'members', 'last_activity', '', '', '', '0', '', '2015-12-29 05:24:57', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('57', '23', 'members', 'last_activity', '', '', '', '0', '', '2015-12-30 11:23:44', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('58', '24', 'members', 'last_activity', '', '', '', '0', '', '2015-12-31 16:17:00', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('59', '25', 'members', 'last_activity', '', '', '', '0', '', '2015-12-31 16:40:03', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('60', '26', 'members', 'last_activity', '', '', '', '0', '', '2015-12-31 16:54:51', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('61', '27', 'members', 'last_activity', '', '', '', '0', '', '2016-01-01 05:21:15', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('73', '1', 'activity', 'activity_update', '<a href="http://circulocristiano.com/members/adminscb/" title="admin@scb">admin@scb</a> posted an update', '<a href=\'http://circulocristiano.com/members/pastorajay/\' rel=\'nofollow\'>@pastorajay</a> Happy New Year.', 'http://circulocristiano.com/members/adminscb/', '0', '0', '2016-01-01 03:56:19', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('74', '28', 'members', 'last_activity', '', '', '', '0', '', '2016-01-01 04:45:23', '0', '0', '0', '0'); 
INSERT INTO `wptz_bp_activity` VALUES ('75', '29', 'members', 'last_activity', '', '', '', '0', '', '2016-01-01 05:26:12', '0', '0', '0', '0');
# --------------------------------------------------------

