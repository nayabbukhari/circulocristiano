CREATE TABLE IF NOT EXISTS `wptz_mywebtonetqtest` (
  `dummydata` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_mywebtonetqtest`;

# --------------------------------------------------------

