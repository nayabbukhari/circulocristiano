CREATE TABLE IF NOT EXISTS `wptz_bp_notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `component_name` varchar(75) NOT NULL,
  `component_action` varchar(75) NOT NULL,
  `date_notified` datetime NOT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `secondary_item_id` (`secondary_item_id`),
  KEY `user_id` (`user_id`),
  KEY `is_new` (`is_new`),
  KEY `component_name` (`component_name`),
  KEY `component_action` (`component_action`),
  KEY `useritem` (`user_id`,`is_new`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
TRUNCATE TABLE `wptz_bp_notifications`;
 
INSERT INTO `wptz_bp_notifications` VALUES ('1', '3', '1', '1', 'friends', 'friendship_request', '2016-01-01 03:55:46', '1'); 
INSERT INTO `wptz_bp_notifications` VALUES ('2', '3', '73', '1', 'activity', 'new_at_mention', '2016-01-01 03:56:19', '1');
# --------------------------------------------------------

