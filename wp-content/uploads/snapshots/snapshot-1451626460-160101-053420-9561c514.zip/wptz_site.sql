CREATE TABLE IF NOT EXISTS `wptz_site` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `domain` (`domain`(140),`path`(51))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_site`;
 
INSERT INTO `wptz_site` VALUES ('1', 'circulocristiano.com', '/');
# --------------------------------------------------------

