CREATE TABLE IF NOT EXISTS `wptz_icl_locale_map` (
  `code` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `code` (`code`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wptz_icl_locale_map`;
 
INSERT INTO `wptz_icl_locale_map` VALUES ('en', 'en_US'); 
INSERT INTO `wptz_icl_locale_map` VALUES ('es', 'es_ES');
# --------------------------------------------------------

