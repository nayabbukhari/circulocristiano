CREATE TABLE IF NOT EXISTS `wptz_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_terms`;
 
INSERT INTO `wptz_terms` VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `wptz_terms` VALUES ('2', 'Primary', 'primary', '0'); 
INSERT INTO `wptz_terms` VALUES ('3', 'Footer', 'footer', '0'); 
INSERT INTO `wptz_terms` VALUES ('4', 'X Demo Menu', 'x-demo-menu', '0'); 
INSERT INTO `wptz_terms` VALUES ('5', 'post-format-video', 'post-format-video', '0'); 
INSERT INTO `wptz_terms` VALUES ('6', 'Sin categorizar', 'sin-categorizar', '0'); 
INSERT INTO `wptz_terms` VALUES ('7', 'Uncategorized @es', 'uncategorized-es', '0');
# --------------------------------------------------------

