CREATE TABLE IF NOT EXISTS `wptz_bp_groups_groupmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
TRUNCATE TABLE `wptz_bp_groups_groupmeta`;
 
INSERT INTO `wptz_bp_groups_groupmeta` VALUES ('1', '1', 'total_member_count', '1'); 
INSERT INTO `wptz_bp_groups_groupmeta` VALUES ('2', '1', 'last_activity', '2015-12-21 21:56:17'); 
INSERT INTO `wptz_bp_groups_groupmeta` VALUES ('3', '1', 'invite_status', 'members');
# --------------------------------------------------------

