CREATE TABLE IF NOT EXISTS `wptz_mywebtonetperfstatsresults` (
  `uniqid` bigint(20) NOT NULL AUTO_INCREMENT,
  `servername` varchar(100) NOT NULL DEFAULT '',
  `serveraddr` varchar(15) NOT NULL DEFAULT '',
  `phpversion` varchar(50) NOT NULL DEFAULT '',
  `phpuname` varchar(50) NOT NULL DEFAULT '',
  `memorylimit` varchar(10) NOT NULL DEFAULT '',
  `postmaxsize` varchar(10) NOT NULL DEFAULT '',
  `mysqlversion` varchar(50) NOT NULL DEFAULT '',
  `phpos` varchar(50) NOT NULL DEFAULT '',
  `serverloadnow` decimal(10,2) NOT NULL DEFAULT '0.00',
  `serverload5` decimal(10,2) NOT NULL DEFAULT '0.00',
  `serverload15` decimal(10,2) NOT NULL DEFAULT '0.00',
  `queryresult` decimal(10,2) NOT NULL DEFAULT '0.00',
  `mysql1` decimal(10,2) NOT NULL DEFAULT '0.00',
  `mysql2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `mysql3` decimal(10,2) NOT NULL DEFAULT '0.00',
  `php1` decimal(10,2) NOT NULL DEFAULT '0.00',
  `php2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `php3` decimal(10,2) NOT NULL DEFAULT '0.00',
  `php4` decimal(10,2) NOT NULL DEFAULT '0.00',
  `networktest` decimal(10,2) NOT NULL DEFAULT '0.00',
  `apacheversion` varchar(100) NOT NULL DEFAULT '',
  `uploadmaxsize` varchar(10) NOT NULL DEFAULT '',
  `maxexectime` int(11) NOT NULL DEFAULT '0',
  `deleteable` int(11) NOT NULL DEFAULT '1',
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uniqid` (`uniqid`),
  KEY `servername` (`servername`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wptz_mywebtonetperfstatsresults`;
 
INSERT INTO `wptz_mywebtonetperfstatsresults` VALUES ('1', 'circulocristiano.com', '8.29.130.239', '5.4.34', 'Linux server.betterbrand.com 2.6.32-042stab085.17 ', '256M', '20M', '5.5.46-cll', 'Linux', '1.06', '0.89', '0.72', '0.27', '7.67', '2.30', '0.95', '0.68', '1.53', '0.75', '1.67', '36.31', 'Test not implemented yet/unknown web server', '20M', '30', '1', '2015-12-13 14:04:25');
# --------------------------------------------------------

