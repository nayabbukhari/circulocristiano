CREATE TABLE IF NOT EXISTS `wptz_bp_xprofile_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `value` longtext NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;
TRUNCATE TABLE `wptz_bp_xprofile_data`;
 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('1', '1', '1', 'admin@scb', '2015-12-27 23:52:40'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('2', '1', '2', 'Ajay Sharma', '2015-12-12 15:53:53'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('3', '2', '2', 'Ajays', '2015-12-12 15:53:53'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('4', '1', '3', 'Ajay Sharma', '2015-12-13 01:56:19'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('5', '1', '4', 'Ajay Sharma', '2015-12-17 11:15:39'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('6', '1', '5', 'fifthstreetchurch-89128', '2015-12-14 06:28:18'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('7', '1', '6', 'Franklin Mercedes', '2015-12-15 20:12:53'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('8', '1', '7', 'adminranveer', '2015-12-21 19:23:26'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('9', '1', '8', 'ranveer', '2015-12-21 19:42:47'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('12', '1', '11', 'scott', '2015-12-24 17:18:32'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('13', '1', '12', 'scottberenzweig', '2015-12-27 04:34:04'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('17', '1', '16', 'testpastor', '2015-12-28 06:38:29'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('18', '1', '17', 'Domingo', '2015-12-27 21:48:26'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('19', '1', '18', 'lunes', '2015-12-27 23:36:59'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('20', '1', '19', 'adminmehul', '2015-12-28 09:14:56'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('21', '1', '20', 'test2', '2015-12-28 12:30:49'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('22', '1', '21', 'scottb', '2015-12-29 05:24:56'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('24', '1', '23', 'ajayitprof', '2015-12-29 08:34:42'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('25', '1', '24', 'lobomon2307', '2015-12-31 16:48:15'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('26', '1', '25', 'mia', '2015-12-31 16:48:15'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('27', '1', '26', 'ygnacio martinez', '2015-12-31 17:31:01'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('28', '1', '27', 'adminmanjinder', '2016-01-01 05:15:48'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('29', '1', '28', 'adminnayab', '2016-01-01 04:25:32'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('30', '1', '30', 'devadmin', '2016-01-01 04:50:36'); 
INSERT INTO `wptz_bp_xprofile_data` VALUES ('31', '1', '29', 'engrnayab', '2016-01-01 04:50:57');
# --------------------------------------------------------

