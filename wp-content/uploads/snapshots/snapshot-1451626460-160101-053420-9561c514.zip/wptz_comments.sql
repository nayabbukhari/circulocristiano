CREATE TABLE IF NOT EXISTS `wptz_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_comments`;
 
INSERT INTO `wptz_comments` VALUES ('1', '1', 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-12-08 04:48:22', '2015-12-08 04:48:22', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', '0', '1', '', '', '0', '0'); 
INSERT INTO `wptz_comments` VALUES ('2', '25', '', '', '', '', '2015-12-11 05:29:04', '2015-12-11 13:29:04', 'Status changed from Pending to Complete', '0', '1', '', 'give_payment_note', '0', '0'); 
INSERT INTO `wptz_comments` VALUES ('3', '285', 'Franklin Mercedes', 'franklin@circuloCristiano.com', '', '162.17.126.1', '2015-12-23 12:38:43', '2015-12-23 20:38:43', 'Where does this comment go to? Is this in response to the library-picture attached?', '0', '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', '', '0', '6'); 
INSERT INTO `wptz_comments` VALUES ('4', '295', 'Franklin Mercedes', 'franklin@circuloCristiano.com', '', '162.17.126.1', '2015-12-23 12:57:20', '2015-12-23 20:57:20', 'This comment area is for what section??', '0', 'post-trashed', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', '', '0', '6'); 
INSERT INTO `wptz_comments` VALUES ('5', '332', '', '', '', '', '2015-12-25 22:40:12', '2015-12-26 06:40:12', 'Status changed from Pending to Complete', '0', '1', '', 'give_payment_note', '0', '0'); 
INSERT INTO `wptz_comments` VALUES ('6', '285', 'admin@scb', 'scottb50@circulocristiano.com', '', '72.193.90.170', '2015-12-27 14:48:10', '2015-12-27 22:48:10', 'it is.', '0', '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', '', '3', '1');
# --------------------------------------------------------

