CREATE TABLE IF NOT EXISTS `wptz_icl_translate_job` (
  `job_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rid` bigint(20) unsigned NOT NULL,
  `translator_id` int(10) unsigned NOT NULL,
  `translated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `manager_id` int(10) unsigned NOT NULL,
  `revision` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`job_id`),
  KEY `rid` (`rid`,`translator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wptz_icl_translate_job`;
 
INSERT INTO `wptz_icl_translate_job` VALUES ('1', '2', '6', '0', '6', ''); 
INSERT INTO `wptz_icl_translate_job` VALUES ('2', '1', '1', '1', '1', '');
# --------------------------------------------------------

