CREATE TABLE IF NOT EXISTS `wptz_moderation_warnings` (
  `warning_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `warning_user_ID` int(11) NOT NULL DEFAULT '0',
  `warning_read` tinyint(1) NOT NULL DEFAULT '0',
  `warning_note` text,
  PRIMARY KEY (`warning_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_moderation_warnings`;

# --------------------------------------------------------

