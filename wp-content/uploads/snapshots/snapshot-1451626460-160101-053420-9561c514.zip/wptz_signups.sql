CREATE TABLE IF NOT EXISTS `wptz_signups` (
  `signup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `title` longtext NOT NULL,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activation_key` varchar(50) NOT NULL DEFAULT '',
  `meta` longtext,
  PRIMARY KEY (`signup_id`),
  KEY `activation_key` (`activation_key`),
  KEY `user_email` (`user_email`),
  KEY `user_login_email` (`user_login`,`user_email`),
  KEY `domain_path` (`domain`(140),`path`(51))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_signups`;
 
INSERT INTO `wptz_signups` VALUES ('1', '', '', '', 'pastorajay', 'pastorajay@example.com', '2015-12-13 01:54:43', '2015-12-13 01:54:43', '1', 'a38c277669d81d0e', 'a:2:{s:11:"add_to_blog";s:1:"1";s:8:"new_role";s:6:"pastor";}'); 
INSERT INTO `wptz_signups` VALUES ('2', '', '', '', 'franklinmercedes', 'franklin@circuloCristiano.com', '2015-12-15 16:10:42', '2015-12-15 16:10:42', '1', '07b76bc8ee54626a', 'a:2:{s:11:"add_to_blog";s:1:"1";s:8:"new_role";s:6:"pastor";}'); 
INSERT INTO `wptz_signups` VALUES ('4', '', '', '', 'adminmehul', 'mehul.kaklotar@gmail.com', '2015-12-28 08:13:48', '2015-12-28 08:13:48', '1', '32b6cdcc82da1047', 'a:2:{s:11:"add_to_blog";s:1:"1";s:8:"new_role";s:13:"administrator";}'); 
INSERT INTO `wptz_signups` VALUES ('5', '', '', '', 'adminmanjinder', 'enggphp.01@gmail.com', '2015-12-31 20:23:42', '2015-12-31 20:26:39', '1', 'cda41bcbd9301da4', 'a:2:{s:11:"add_to_blog";s:1:"1";s:8:"new_role";s:13:"administrator";}'); 
INSERT INTO `wptz_signups` VALUES ('6', '', '', '', 'adminnayab', 'bec_dir@yahoo.com', '2016-01-01 04:14:18', '2016-01-01 04:20:43', '1', 'beace6223d1f6df1', 'a:2:{s:11:"add_to_blog";s:1:"1";s:8:"new_role";s:13:"administrator";}'); 
INSERT INTO `wptz_signups` VALUES ('7', '', '', '', 'engrnayab', 'becdir@gmail.com', '2016-01-01 04:40:24', '2016-01-01 04:45:23', '1', 'b51cb317b754aa04', 'a:2:{s:11:"add_to_blog";s:1:"1";s:8:"new_role";s:13:"administrator";}'); 
INSERT INTO `wptz_signups` VALUES ('8', '', '', '', 'devadmin', 'dev@CirculoCristiano.com', '2016-01-01 04:50:36', '2016-01-01 04:50:36', '1', '483b5f921c77f6bf', 'a:2:{s:11:"add_to_blog";s:1:"1";s:8:"new_role";s:13:"administrator";}');
# --------------------------------------------------------

