CREATE TABLE IF NOT EXISTS `wptz_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wptz_rg_form`;
 
INSERT INTO `wptz_rg_form` VALUES ('1', 'Solicite su invitación a Circulo Cristiano.', '2015-12-29 05:11:31', '1', '0');
# --------------------------------------------------------

