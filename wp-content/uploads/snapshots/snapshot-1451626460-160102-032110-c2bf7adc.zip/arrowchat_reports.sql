CREATE TABLE IF NOT EXISTS `arrowchat_reports` (
  `id` int(25) unsigned NOT NULL AUTO_INCREMENT,
  `report_from` varchar(25) NOT NULL,
  `report_about` varchar(25) NOT NULL,
  `report_chatroom` int(10) unsigned NOT NULL,
  `report_time` int(20) unsigned NOT NULL,
  `working_by` varchar(25) NOT NULL,
  `working_time` int(20) unsigned NOT NULL,
  `completed_by` varchar(25) NOT NULL,
  `completed_time` int(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `arrowchat_reports`;

# --------------------------------------------------------

