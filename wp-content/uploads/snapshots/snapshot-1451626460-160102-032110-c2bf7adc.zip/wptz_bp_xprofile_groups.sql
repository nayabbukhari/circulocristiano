CREATE TABLE IF NOT EXISTS `wptz_bp_xprofile_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `description` mediumtext NOT NULL,
  `group_order` bigint(20) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `can_delete` (`can_delete`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
TRUNCATE TABLE `wptz_bp_xprofile_groups`;
 
INSERT INTO `wptz_bp_xprofile_groups` VALUES ('1', 'Base', '', '0', '0');
# --------------------------------------------------------

