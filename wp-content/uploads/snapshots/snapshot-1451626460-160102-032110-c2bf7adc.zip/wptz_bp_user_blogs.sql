CREATE TABLE IF NOT EXISTS `wptz_bp_user_blogs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `blog_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
TRUNCATE TABLE `wptz_bp_user_blogs`;
 
INSERT INTO `wptz_bp_user_blogs` VALUES ('1', '1', '1'); 
INSERT INTO `wptz_bp_user_blogs` VALUES ('2', '2', '1'); 
INSERT INTO `wptz_bp_user_blogs` VALUES ('3', '27', '1'); 
INSERT INTO `wptz_bp_user_blogs` VALUES ('5', '8', '1'); 
INSERT INTO `wptz_bp_user_blogs` VALUES ('6', '5', '2'); 
INSERT INTO `wptz_bp_user_blogs` VALUES ('7', '5', '3'); 
INSERT INTO `wptz_bp_user_blogs` VALUES ('9', '29', '1'); 
INSERT INTO `wptz_bp_user_blogs` VALUES ('10', '30', '1');
# --------------------------------------------------------

