CREATE TABLE IF NOT EXISTS `wptz_blog_versions` (
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `db_version` varchar(20) NOT NULL DEFAULT '',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`blog_id`),
  KEY `db_version` (`db_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_blog_versions`;
 
INSERT INTO `wptz_blog_versions` VALUES ('1', '35700', '2015-12-09 00:31:32');
# --------------------------------------------------------

