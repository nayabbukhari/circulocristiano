CREATE TABLE IF NOT EXISTS `arrowchat_chatroom_users` (
  `user_id` varchar(25) COLLATE utf8_bin NOT NULL,
  `chatroom_id` int(10) unsigned NOT NULL,
  `is_admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_mod` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `block_chats` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `silence_length` int(3) unsigned DEFAULT NULL,
  `silence_time` int(15) unsigned DEFAULT NULL,
  `session_time` int(15) unsigned NOT NULL,
  UNIQUE KEY `user_id` (`user_id`,`chatroom_id`),
  KEY `chatroom_id` (`chatroom_id`),
  KEY `is_admin` (`is_admin`),
  KEY `is_mod` (`is_mod`),
  KEY `session_time` (`session_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
TRUNCATE TABLE `arrowchat_chatroom_users`;

# --------------------------------------------------------

