CREATE TABLE IF NOT EXISTS `arrowchat_chatroom_banlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(25) COLLATE utf8_bin NOT NULL,
  `chatroom_id` int(10) unsigned NOT NULL,
  `ban_length` int(10) unsigned NOT NULL,
  `ban_time` int(10) unsigned NOT NULL,
  `ip_address` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `chatroom_id` (`chatroom_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
TRUNCATE TABLE `arrowchat_chatroom_banlist`;

# --------------------------------------------------------

