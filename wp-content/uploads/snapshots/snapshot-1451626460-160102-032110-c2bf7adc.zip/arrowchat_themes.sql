CREATE TABLE IF NOT EXISTS `arrowchat_themes` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `folder` varchar(25) NOT NULL,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL,
  `update_link` varchar(255) DEFAULT NULL,
  `version` varchar(20) DEFAULT NULL,
  `default` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `arrowchat_themes`;
 
INSERT INTO `arrowchat_themes` VALUES ('1', 'new_facebook_full', 'New Facebook Full', '1', 'http://www.arrowchat.com/updatecheck.php?id=8', '5.4', '1');
# --------------------------------------------------------

