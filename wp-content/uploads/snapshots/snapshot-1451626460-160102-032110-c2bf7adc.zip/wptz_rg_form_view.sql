CREATE TABLE IF NOT EXISTS `wptz_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wptz_rg_form_view`;
 
INSERT INTO `wptz_rg_form_view` VALUES ('1', '0', '2015-12-29 05:09:34', '8.29.130.239', '1'); 
INSERT INTO `wptz_rg_form_view` VALUES ('2', '1', '2015-12-30 09:52:43', '72.193.90.170', '1'); 
INSERT INTO `wptz_rg_form_view` VALUES ('3', '1', '2015-12-30 11:23:44', '124.253.149.190', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('4', '1', '2015-12-30 13:11:28', '124.253.149.190', '55'); 
INSERT INTO `wptz_rg_form_view` VALUES ('5', '1', '2015-12-30 14:50:38', '47.22.67.66', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('6', '1', '2015-12-30 15:26:08', '148.103.92.254', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('7', '1', '2015-12-30 16:27:46', '72.193.90.170', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('8', '1', '2015-12-30 18:06:35', '108.21.202.21', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('9', '1', '2015-12-30 19:04:12', '190.167.166.231', '10'); 
INSERT INTO `wptz_rg_form_view` VALUES ('10', '1', '2015-12-30 20:32:28', '72.193.90.170', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('11', '1', '2015-12-30 21:05:17', '64.32.117.150', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('12', '1', '2015-12-30 23:50:27', '69.123.73.134', '10'); 
INSERT INTO `wptz_rg_form_view` VALUES ('13', '1', '2015-12-31 01:07:20', '186.149.15.146', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('14', '1', '2015-12-31 02:44:14', '68.199.157.211', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('15', '1', '2015-12-31 03:28:31', '124.253.149.190', '20'); 
INSERT INTO `wptz_rg_form_view` VALUES ('16', '1', '2015-12-31 05:03:29', '124.253.149.190', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('17', '1', '2015-12-31 06:16:38', '123.125.71.30', '25'); 
INSERT INTO `wptz_rg_form_view` VALUES ('18', '1', '2015-12-31 07:07:10', '124.253.149.190', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('19', '1', '2015-12-31 08:56:02', '54.244.247.32', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('20', '1', '2015-12-31 11:38:38', '71.190.144.79', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('21', '1', '2015-12-31 12:04:25', '100.8.80.77', '10'); 
INSERT INTO `wptz_rg_form_view` VALUES ('22', '1', '2015-12-31 13:20:34', '172.56.35.57', '10'); 
INSERT INTO `wptz_rg_form_view` VALUES ('23', '1', '2015-12-31 15:13:56', '124.253.50.24', '25'); 
INSERT INTO `wptz_rg_form_view` VALUES ('24', '1', '2015-12-31 16:02:24', '47.22.67.66', '45'); 
INSERT INTO `wptz_rg_form_view` VALUES ('25', '1', '2015-12-31 17:03:00', '72.193.90.170', '20'); 
INSERT INTO `wptz_rg_form_view` VALUES ('26', '1', '2015-12-31 19:25:22', '186.7.148.51', '10'); 
INSERT INTO `wptz_rg_form_view` VALUES ('27', '1', '2015-12-31 23:27:12', '66.87.117.131', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('28', '1', '2016-01-01 01:59:56', '67.81.147.169', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('29', '1', '2016-01-01 03:00:06', '172.56.18.122', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('30', '1', '2016-01-01 04:05:33', '66.249.83.114', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('31', '1', '2016-01-01 05:32:48', '172.56.2.72', '35'); 
INSERT INTO `wptz_rg_form_view` VALUES ('32', '1', '2016-01-01 07:08:23', '104.192.143.193', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('33', '1', '2016-01-01 10:08:40', '96.225.88.165', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('34', '1', '2016-01-01 11:15:11', '182.180.153.138', '40'); 
INSERT INTO `wptz_rg_form_view` VALUES ('35', '1', '2016-01-01 13:54:57', '124.253.49.137', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('36', '1', '2016-01-01 14:15:21', '124.253.49.137', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('37', '1', '2016-01-01 15:09:08', '124.253.49.137', '15'); 
INSERT INTO `wptz_rg_form_view` VALUES ('38', '1', '2016-01-01 18:31:34', '52.8.59.90', '20'); 
INSERT INTO `wptz_rg_form_view` VALUES ('39', '1', '2016-01-01 20:03:09', '74.65.241.130', '25'); 
INSERT INTO `wptz_rg_form_view` VALUES ('40', '1', '2016-01-01 21:12:27', '68.174.95.100', '10'); 
INSERT INTO `wptz_rg_form_view` VALUES ('41', '1', '2016-01-02 00:33:00', '50.132.85.131', '5'); 
INSERT INTO `wptz_rg_form_view` VALUES ('42', '1', '2016-01-02 02:33:22', '66.249.84.111', '5');
# --------------------------------------------------------

