CREATE TABLE IF NOT EXISTS `arrowchat_status` (
  `userid` varchar(25) NOT NULL,
  `guest_name` varchar(50) DEFAULT NULL,
  `message` text,
  `status` varchar(10) DEFAULT NULL,
  `theme` int(3) unsigned DEFAULT NULL,
  `popout` int(11) unsigned DEFAULT NULL,
  `typing` text,
  `hide_bar` tinyint(1) unsigned DEFAULT NULL,
  `play_sound` tinyint(1) unsigned DEFAULT '1',
  `window_open` tinyint(1) unsigned DEFAULT NULL,
  `only_names` tinyint(1) unsigned DEFAULT NULL,
  `chatroom_window` varchar(6) NOT NULL DEFAULT '-1',
  `chatroom_stay` varchar(6) NOT NULL DEFAULT '0',
  `chatroom_show_names` tinyint(1) unsigned DEFAULT NULL,
  `chatroom_block_chats` tinyint(1) unsigned DEFAULT NULL,
  `chatroom_sound` tinyint(1) unsigned DEFAULT NULL,
  `announcement` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `unfocus_chat` text,
  `focus_chat` varchar(50) DEFAULT NULL,
  `last_message` text,
  `clear_chats` text,
  `apps_bookmarks` text,
  `apps_other` text,
  `apps_open` int(10) unsigned DEFAULT NULL,
  `apps_load` text,
  `block_chats` text,
  `session_time` int(20) unsigned NOT NULL DEFAULT '0',
  `is_admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_mod` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hash_id` varchar(20) NOT NULL DEFAULT '0',
  `ip_address` varchar(40) DEFAULT '',
  PRIMARY KEY (`userid`),
  KEY `hash_id` (`hash_id`),
  KEY `session_time` (`session_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `arrowchat_status`;
 
INSERT INTO `arrowchat_status` VALUES ('', '', '', 'away', '', '', '', '', '1', '', '', '-1', '0', '', '', '', '1', '', '', '', '', '', '', '', '', '', '0', '0', '0', '0', ''); 
INSERT INTO `arrowchat_status` VALUES ('1', '', '', 'available', '', '99', '', '0', '1', '', '', '-1', '0', '', '', '', '1', '', '', '', '', '', '', '', '', '', '1450298352', '0', '0', 'GGu2xm4BJbIBooYrPH8t', '72.193.90.170'); 
INSERT INTO `arrowchat_status` VALUES ('2', '', '', 'available', '', '1450146504', '', '0', '1', '', '', '-1', '0', '', '', '', '1', '', '', '', '', '', '', '', '', '', '1450257175', '0', '0', 'Tu68Q29HALqyuyoq6sCI', '124.253.200.184'); 
INSERT INTO `arrowchat_status` VALUES ('3', '', '', 'away', '', '', '', '', '1', '', '', '-1', '0', '', '', '', '1', '', '', '', '', '', '', '', '', '', '1450386025', '0', '0', 'Kn8oTTTYq4sDaRLJxXCw', '64.62.219.59'); 
INSERT INTO `arrowchat_status` VALUES ('4', '', '', 'available', '', '', '', '', '1', '', '', '-1', '0', '', '', '', '1', '', '', '', '', '', '', '', '', '', '1450193988', '0', '0', 'sRxhzXFjhIR9ycToeTYu', '124.253.159.75'); 
INSERT INTO `arrowchat_status` VALUES ('6', '', '', '', '', '', '', '', '1', '', '', '-1', '0', '', '', '', '1', '', '', '', '', '', '', '', '', '', '1450209062', '0', '0', 'Q6rmNJR8U21Ww6ewusan', '47.22.67.66');
# --------------------------------------------------------

