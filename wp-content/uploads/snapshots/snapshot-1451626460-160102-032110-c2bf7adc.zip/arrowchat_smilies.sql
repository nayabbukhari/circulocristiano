CREATE TABLE IF NOT EXISTS `arrowchat_smilies` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `code` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `arrowchat_smilies`;
 
INSERT INTO `arrowchat_smilies` VALUES ('1', 'smile', ':)'); 
INSERT INTO `arrowchat_smilies` VALUES ('2', 'big_grin', ':D'); 
INSERT INTO `arrowchat_smilies` VALUES ('3', 'wink', ';)'); 
INSERT INTO `arrowchat_smilies` VALUES ('4', 'agape', ':o'); 
INSERT INTO `arrowchat_smilies` VALUES ('5', 'bored', ':|'); 
INSERT INTO `arrowchat_smilies` VALUES ('6', 'crying', ':\'('); 
INSERT INTO `arrowchat_smilies` VALUES ('7', 'tongue', ':p'); 
INSERT INTO `arrowchat_smilies` VALUES ('8', 'confused', ':s'); 
INSERT INTO `arrowchat_smilies` VALUES ('9', 'smile', ':-)'); 
INSERT INTO `arrowchat_smilies` VALUES ('10', 'frown', ':-('); 
INSERT INTO `arrowchat_smilies` VALUES ('11', 'wink', ';-)'); 
INSERT INTO `arrowchat_smilies` VALUES ('12', 'agape', ':-o'); 
INSERT INTO `arrowchat_smilies` VALUES ('13', 'bored', ':-|'); 
INSERT INTO `arrowchat_smilies` VALUES ('14', 'tongue', ':-p'); 
INSERT INTO `arrowchat_smilies` VALUES ('15', 'confused', ':-s'); 
INSERT INTO `arrowchat_smilies` VALUES ('16', 'mad', '>:('); 
INSERT INTO `arrowchat_smilies` VALUES ('17', 'dead', 'X('); 
INSERT INTO `arrowchat_smilies` VALUES ('18', 'delicious', '[delicious]'); 
INSERT INTO `arrowchat_smilies` VALUES ('19', 'dont_cry', '[dontcry]'); 
INSERT INTO `arrowchat_smilies` VALUES ('20', 'evil', '[evil]'); 
INSERT INTO `arrowchat_smilies` VALUES ('21', 'evil_grin', '[evilgrin]'); 
INSERT INTO `arrowchat_smilies` VALUES ('22', 'impatient', '[impatient]'); 
INSERT INTO `arrowchat_smilies` VALUES ('23', 'inlove', '<3'); 
INSERT INTO `arrowchat_smilies` VALUES ('24', 'kiss', ':-*'); 
INSERT INTO `arrowchat_smilies` VALUES ('25', 'nerdy', '[nerd]'); 
INSERT INTO `arrowchat_smilies` VALUES ('26', 'not_even', '[noteven]'); 
INSERT INTO `arrowchat_smilies` VALUES ('27', 'oh_rly', '[ohrly]'); 
INSERT INTO `arrowchat_smilies` VALUES ('28', 'shocked', '[shocked]'); 
INSERT INTO `arrowchat_smilies` VALUES ('29', 'sick', '[sick]'); 
INSERT INTO `arrowchat_smilies` VALUES ('30', 'sing', '[sing]'); 
INSERT INTO `arrowchat_smilies` VALUES ('31', 'stress', '[stress]'); 
INSERT INTO `arrowchat_smilies` VALUES ('32', 'sunglasses_1', '8)'); 
INSERT INTO `arrowchat_smilies` VALUES ('33', 'whistle', '[whistle]'); 
INSERT INTO `arrowchat_smilies` VALUES ('34', 'yawn', '[yawn]'); 
INSERT INTO `arrowchat_smilies` VALUES ('35', 'zipped', ':X'); 
INSERT INTO `arrowchat_smilies` VALUES ('36', 'frown', ':(');
# --------------------------------------------------------

