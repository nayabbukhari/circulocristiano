CREATE TABLE IF NOT EXISTS `arrowchat_chatroom_rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` varchar(25) COLLATE utf8_bin NOT NULL,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `description` varchar(100) COLLATE utf8_bin DEFAULT '',
  `welcome_message` varchar(255) COLLATE utf8_bin DEFAULT '',
  `image` varchar(100) COLLATE utf8_bin DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL,
  `password` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `length` int(10) unsigned NOT NULL,
  `max_users` int(10) NOT NULL DEFAULT '0',
  `limit_message_num` int(5) NOT NULL DEFAULT '3',
  `limit_seconds_num` int(5) NOT NULL DEFAULT '10',
  `disallowed_groups` text COLLATE utf8_bin NOT NULL,
  `session_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `session_time` (`session_time`),
  KEY `author_id` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
TRUNCATE TABLE `arrowchat_chatroom_rooms`;

# --------------------------------------------------------

