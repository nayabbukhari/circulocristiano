CREATE TABLE IF NOT EXISTS `wptz_sl_tag` (
  `sl_tag_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sl_tag_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_tag_slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_id` mediumint(8) DEFAULT NULL,
  PRIMARY KEY (`sl_tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
TRUNCATE TABLE `wptz_sl_tag`;

# --------------------------------------------------------

