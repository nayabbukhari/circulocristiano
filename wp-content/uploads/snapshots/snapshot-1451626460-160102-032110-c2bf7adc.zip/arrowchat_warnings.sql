CREATE TABLE IF NOT EXISTS `arrowchat_warnings` (
  `id` int(25) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(25) NOT NULL,
  `warn_reason` text,
  `warned_by` varchar(25) NOT NULL,
  `warning_time` int(20) unsigned NOT NULL,
  `user_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `arrowchat_warnings`;

# --------------------------------------------------------

