CREATE TABLE IF NOT EXISTS `wptz_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wptz_rg_lead_detail`;
 
INSERT INTO `wptz_rg_lead_detail` VALUES ('1', '3', '1', '1', 'bob'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('2', '3', '1', '3', 'bob@bon.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('3', '3', '1', '4.1', '1'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('4', '4', '1', '1', 'Rebeca Cruz'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('5', '4', '1', '3', 'rebecacruz1986@gmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('6', '5', '1', '1', 'Maria Elena Martinez'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('7', '5', '1', '3', 'vision1330@tricom.net'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('8', '6', '1', '1', 'Mary Estrada'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('9', '6', '1', '3', 'estradamary2008@hotmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('10', '7', '1', '1', 'TERESA CARRASCO'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('11', '7', '1', '3', 'carrasco.teresa@gmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('12', '8', '1', '1', 'jokebed'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('13', '8', '1', '3', 'lamilorestupenda@hotmail.es'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('14', '9', '1', '1', 'Rafael.'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('15', '9', '1', '3', 'rafael.ayala27@hotmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('16', '10', '1', '1', 'Martin perez'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('17', '10', '1', '3', '06mperez@gmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('18', '10', '1', '4.1', '1'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('19', '11', '1', '1', 'franklin A Garcia'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('20', '11', '1', '3', 'peluca0926@hotmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('21', '12', '1', '1', 'George rojas'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('22', '12', '1', '3', 'evangelistarojas05@yahoo.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('23', '13', '1', '1', 'bob'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('24', '13', '1', '3', 'scottb50@gmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('25', '13', '1', '4.1', '1'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('26', '14', '1', '1', 'Victor Nieves'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('27', '14', '1', '3', 'revvmn@aol.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('28', '14', '1', '4.1', '1'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('29', '15', '1', '1', 'eliazar'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('30', '15', '1', '3', 'eliazarperdomo23@outlook.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('31', '16', '1', '1', 'eliazar'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('32', '16', '1', '3', 'eliazarperdomo23@outlook.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('33', '17', '1', '1', 'eliazar'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('34', '17', '1', '3', 'eliazarperdomo23@outlook.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('35', '18', '1', '1', 'jokebed'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('36', '18', '1', '3', 'lamilorestupenda@hotmail.es'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('37', '19', '1', '1', 'jokebed'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('38', '19', '1', '3', 'lamilorestupenda@hotmail.es'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('39', '20', '1', '1', 'Ygnacio Martinez'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('40', '20', '1', '3', 'evemar459@yahoo.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('41', '20', '1', '4.1', '1'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('42', '21', '1', '1', 'Evelyn Martinez'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('43', '21', '1', '3', 'evemar459@yahoo.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('44', '22', '1', '1', 'Arelis ALMANZAR'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('45', '22', '1', '3', 'Laperla2424@gmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('46', '22', '1', '4.1', '1'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('47', '23', '1', '1', 'Mercedes Ruiz'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('48', '23', '1', '3', 'AmorcitoAriasRuiz@hotmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('49', '24', '1', '1', 'Fausto mejia'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('50', '24', '1', '3', 'Faustomejia22@gmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('51', '24', '1', '4.1', '1'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('52', '25', '1', '1', 'Care ortiz'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('53', '25', '1', '3', 'Ortizmery719@gmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('54', '26', '1', '1', 'Carolina Ayala'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('55', '26', '1', '3', 'cc.ayalach@gmail.com'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('56', '27', '1', '1', 'Francisco Quinteros'); 
INSERT INTO `wptz_rg_lead_detail` VALUES ('57', '27', '1', '3', 'pacoquinteros@hotmail.com');
# --------------------------------------------------------

