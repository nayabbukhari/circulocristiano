CREATE TABLE IF NOT EXISTS `wptz_give_customers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `name` mediumtext NOT NULL,
  `purchase_value` mediumtext NOT NULL,
  `purchase_count` bigint(20) NOT NULL,
  `payment_ids` longtext NOT NULL,
  `notes` longtext NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_give_customers`;
 
INSERT INTO `wptz_give_customers` VALUES ('1', '2', 'ajayitprof@gmail.com', 'ajay Sharma', '1.000000', '1', '25', '', '2015-12-11 05:29:04'); 
INSERT INTO `wptz_give_customers` VALUES ('2', '3', 'pastorajay@example.com', 'Ajay Sharma', '1.000000', '1', '332', '', '2015-12-25 22:40:12');
# --------------------------------------------------------

