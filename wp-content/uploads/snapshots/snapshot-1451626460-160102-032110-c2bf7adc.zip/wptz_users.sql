CREATE TABLE IF NOT EXISTS `wptz_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_users`;
 
INSERT INTO `wptz_users` VALUES ('1', 'admin@scb', '$P$Bvc7.51gon2QLOkAzzbJLgY6C/zXNG1', 'adminscb', 'scottb50@circulocristiano.com', '', '2015-12-08 04:48:22', '', '0', 'admin@scb', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('2', 'adminajay', '$P$BAAdxGY5cr61UAAVvaZnugkQnNK/7e/', 'adminajay', 'ajayitprof@gmail.com', '', '2015-12-11 04:59:41', '1449809981:$P$BCc0KdIqq4LIHOTKvZA1YAtUPhOtVR/', '0', 'Ajay Sharma', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('3', 'pastorajay', '$P$BJ1o.kwzJExnNnYrFKWNVqgxWV3i.61', 'pastorajay', 'pastorajay@example.com', '', '2015-12-13 01:54:43', '', '0', 'Ajay Sharma', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('4', 'memberajay', '$P$Bc2hqa4zqU0lh/jZDe/QwuvcVS.jl//', 'memberajay', 'memberajay@example.com', '', '2015-12-13 18:54:54', '', '0', 'Ajay Sharma', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('5', 'fifthstreetchurch-89128', '$P$B/DMiEEUuKlU4gAfQ/rGef1CYg2Q0k.', 'fifthstreetchurch-89128', 'Scott@CirculoCristiano.com', '', '2015-12-14 06:28:18', '1450074499:$P$Bcp1TxaOG.xQ5D1v0fbZOw.0qNqUKa1', '0', 'fifthstreetchurch-89128', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('6', 'franklinmercedes', '$P$B9TOQPGgumUKNVH.lXmA.Q9c7s1kDD0', 'franklinmercedes', 'franklin@circuloCristiano.com', '', '2015-12-15 16:10:42', '', '0', 'Franklin Mercedes', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('7', 'adminranveer', '$P$BRfDhiduuKumztZyEW9DdneQwCFWmI/', 'adminranveer', 'ranveer@live.in', '', '2015-12-17 23:34:24', '', '0', 'adminranveer', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('8', 'ranveer', '$P$BHRnS80RTAR7M0/GXP/y28nv/3CHHO.', 'ranveer', 'myacct1@mydomain.com', '', '2015-12-18 05:07:40', '', '0', 'ranveer', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('11', 'scott', '$P$B8jq7VSJ.QsGsquqBPHVE5RIOZuof9.', 'scott', 'scott@betterbrand.com', '', '2015-12-24 17:18:32', '', '0', 'scott', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('12', 'scottberenzweig', '$P$BEwtrOEbD7YnHywK8H.p0ub/FPraXL.', 'scottberenzweig', 'scott.b@circuloCristiano.com', '', '2015-12-27 04:34:04', '1451190844:$P$BFAt5O7716Ipvyz9V/PAPhABI/zijp.', '0', 'scottberenzweig', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('16', 'test', '$P$BRH43P47jzJHKQv.js5.5/66VlpQgv0', 'test', 'test@gmail.com', '', '2015-12-27 13:32:10', '', '0', 'testpastor', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('17', 'domingo', '$P$BdHlTazp0/u6sZSTdHGsoeFFQ7JO7Y0', 'domingo', 'domingo@CirculoCristiano.com', '', '2015-12-27 21:29:30', '1451251771:$P$BVYAMU5G7jb/HJKY/7YHtCW8vr8jux0', '0', 'Domingo', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('18', 'lunes', '$P$B6z8iDYJ4AFIf98.e1vOML95enc9t/.', 'lunes', 'omid@circulocristiano.com', '', '2015-12-27 23:28:45', '', '0', 'lunes', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('20', 'test2', '$P$BIuzi1hoRoA2RjCihevAyUHBCOW0OG0', 'test2', 'test2@example.com', '', '2015-12-28 12:30:49', '', '0', 'test2', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('21', 'scottb', '$P$BoooJtb0ylrMu7bbMw3StMbAli8zwv0', 'scottb', 'scot.b@circuloCristiano.com', '', '2015-12-29 05:24:56', '', '0', 'scottb', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('23', 'ajayitprof', '$P$BdYyszuf4bGc0SW4ysM.UVnhmAHQQZ0', 'ajayitprof', 'ajayitprof3@gmail.com', '', '2015-12-29 08:33:55', '1451378035:$P$BNsCBYLvec/O8cD2FeZomX3pGM7F4k/', '0', 'ajayitprof', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('24', 'lobomon2307', '$P$BAB/pGWSz2XuVy80YmM7SsTc1pO6aK0', 'lobomon2307', 'eliazarperdomo23@outlook.com', '', '2015-12-31 16:16:55', '1451578615:$P$B.bA7/C38RpyZZs8e2b.Moi6yp2qk3.', '0', 'lobomon2307', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('25', 'mia', '$P$B5P5BnZABEPOsIh7zFSB2p0LP0/q3y1', 'mia', 'germania.03@hotmail.com', '', '2015-12-31 16:39:57', '1451579997:$P$BLkq6xD6.u0URV8o7ID8SkJVwNeHYx1', '0', 'mia', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('26', 'ygnacio martinez', '$P$BXKVrJhdFm3Cj.KZ..cGzCl0Iqqqe50', 'ygnacio-martinez', 'evemar459@yahoo.com', '', '2015-12-31 16:54:46', '1451580886:$P$B7.izQOjM8I3.Fc6JFU/NCr8xA0en10', '0', 'ygnacio martinez', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('27', 'adminmanjinder', '$P$BWji8IrVQPtBFIEnYEB50UFwRp3brf0', 'adminmanjinder', 'enggphp.01@gmail.com', '', '2015-12-31 20:26:39', '', '0', 'adminmanjinder', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('28', 'adminnayab', '$P$Bvc1qXJ9pmYy.kVfyQ/OenK1p3tQBh1', 'adminnayab', 'bec_dir@yahoo.com', '', '2016-01-01 04:20:42', '', '0', 'adminnayab', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('29', 'engrnayab', '$P$BCgyuUxHH.r5ixDvZQa8Gv1oGL4DQs0', 'engrnayab', 'becdir@gmail.com', '', '2016-01-01 04:45:23', '', '0', 'engrnayab', '0', '0'); 
INSERT INTO `wptz_users` VALUES ('30', 'devadmin', '$P$BCJx7j1g2piMxDItNc./AD8pE5tZFK/', 'devadmin', 'dev@CirculoCristiano.com', '', '2016-01-01 04:50:36', '', '0', 'devadmin', '0', '0');
# --------------------------------------------------------

