CREATE TABLE IF NOT EXISTS `wptz_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wptz_rg_lead`;
 
INSERT INTO `wptz_rg_lead` VALUES ('3', '1', '', '2015-12-30 09:39:18', '0', '0', '72.193.90.170', 'http://circulocristiano.com/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '1', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('4', '1', '', '2015-12-30 15:10:44', '0', '0', '47.22.67.66', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '6', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('5', '1', '', '2015-12-30 15:28:06', '0', '0', '148.103.92.254', 'https://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('6', '1', '', '2015-12-30 18:08:33', '0', '0', '108.21.202.21', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('7', '1', '', '2015-12-30 19:05:12', '0', '1', '190.167.166.231', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('8', '1', '', '2015-12-31 01:09:11', '0', '0', '186.149.15.146', 'http://circulocristiano.com/', 'Mozilla/5.0 (Linux; Android 4.4.2; S700A Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('9', '1', '', '2015-12-31 02:47:08', '0', '0', '68.199.157.211', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:43.0) Gecko/20100101 Firefox/43.0', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('10', '1', '', '2015-12-31 12:07:54', '0', '0', '63.143.201.212', 'http://circulocristiano.com/', 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13C75 Safari/601.1', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('11', '1', '', '2015-12-31 13:22:56', '0', '0', '172.56.35.57', 'http://circulocristiano.com/', 'Mozilla/5.0 (Linux; Android 4.4.2; es-us; SAMSUNG-SM-G870A Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.6 Chrome/28.0.1500.94 Mobile Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('12', '1', '', '2015-12-31 13:58:47', '0', '0', '172.56.18.122', 'http://circulocristiano.com/', 'Mozilla/5.0 (Linux; Android 4.4.4; en-us; SAMSUNG SGH-M919N Build/KTU84P) AppleWebKit/537.36 (KHTML, like Gecko) Version/1.5 Chrome/28.0.1500.94 Mobile Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('13', '1', '', '2015-12-31 16:04:16', '0', '0', '72.193.90.170', 'http://circulocristiano.com/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '1', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('14', '1', '', '2015-12-31 16:10:43', '0', '0', '47.22.67.66', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '6', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('15', '1', '', '2015-12-31 16:20:37', '0', '0', '47.18.229.238', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '24', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('16', '1', '', '2015-12-31 16:21:28', '0', '0', '47.18.229.238', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '24', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('17', '1', '', '2015-12-31 16:21:30', '0', '0', '47.18.229.238', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '24', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('18', '1', '', '2015-12-31 16:27:27', '0', '0', '186.149.15.146', 'http://circulocristiano.com/', 'Mozilla/5.0 (Linux; Android 4.4.2; S700A Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('19', '1', '', '2015-12-31 16:27:29', '0', '0', '186.149.15.146', 'http://circulocristiano.com/', 'Mozilla/5.0 (Linux; Android 4.4.2; S700A Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('20', '1', '', '2015-12-31 16:52:08', '0', '0', '100.12.252.198', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('21', '1', '', '2015-12-31 17:00:04', '0', '0', '100.12.252.198', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('22', '1', '', '2015-12-31 17:02:10', '0', '0', '24.186.67.39', 'http://circulocristiano.com/', 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13C75 Safari/601.1', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('23', '1', '', '2015-12-31 19:27:25', '0', '0', '186.7.148.51', 'http://circulocristiano.com/', 'Mozilla/5.0 (Windows NT 5.1; rv:43.0) Gecko/20100101 Firefox/43.0', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('24', '1', '', '2015-12-31 23:29:37', '0', '0', '66.87.117.131', 'http://circulocristiano.com/', 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F70 Safari/600.1.4', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('25', '1', '', '2016-01-01 03:06:06', '0', '0', '63.143.231.196', 'http://circulocristiano.com/', 'Mozilla/5.0 (Linux; Android 5.1.1; SM-G360T Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.83 Mobile Safari/537.36', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('26', '1', '', '2016-01-01 10:11:29', '0', '0', '96.225.88.165', 'http://circulocristiano.com/', 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13C75 Safari/601.1', 'USD', '', '', '', '', '', '', '', '', 'active'); 
INSERT INTO `wptz_rg_lead` VALUES ('27', '1', '', '2016-01-01 21:14:17', '0', '0', '68.174.95.100', 'http://circulocristiano.com/', 'Mozilla/5.0 (Linux; U; Android 4.2.2; es-us; Venue 8 3830 Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30', 'USD', '', '', '', '', '', '', '', '', 'active');
# --------------------------------------------------------

