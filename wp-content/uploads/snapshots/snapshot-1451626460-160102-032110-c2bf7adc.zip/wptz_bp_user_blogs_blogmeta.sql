CREATE TABLE IF NOT EXISTS `wptz_bp_user_blogs_blogmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;
TRUNCATE TABLE `wptz_bp_user_blogs_blogmeta`;
 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('2', '1', 'name', 'Circulo Cristiano'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('3', '1', 'description', 'Iglesia. Comunidad. Misiones.'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('4', '1', 'last_activity', '2016-01-01 09:51:04'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('5', '1', 'close_comments_for_old_posts', ''); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('6', '1', 'close_comments_days_old', '14'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('7', '1', 'thread_comments_depth', '5'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('8', '2', 'url', 'http://circulocristiano.com/fifthstreetchurch-89128'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('9', '2', 'name', 'Fifth Street Church'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('10', '2', 'description', 'Just another Circulo Cristiano site'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('11', '2', 'last_activity', '2016-01-01 02:54:19'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('12', '2', 'close_comments_for_old_posts', '0'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('13', '2', 'close_comments_days_old', '14'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('14', '2', 'thread_comments_depth', '5'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('15', '3', 'url', 'http://circulocristiano.com/peacegivinglove-33431'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('16', '3', 'name', 'Church of Peace'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('17', '3', 'description', 'Just another Circulo Cristiano site'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('18', '3', 'last_activity', '2016-01-01 02:54:19'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('19', '3', 'close_comments_for_old_posts', '0'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('20', '3', 'close_comments_days_old', '14'); 
INSERT INTO `wptz_bp_user_blogs_blogmeta` VALUES ('21', '3', 'thread_comments_depth', '5');
# --------------------------------------------------------

