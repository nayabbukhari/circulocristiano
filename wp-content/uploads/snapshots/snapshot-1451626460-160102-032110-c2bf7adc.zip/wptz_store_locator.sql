CREATE TABLE IF NOT EXISTS `wptz_store_locator` (
  `sl_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sl_store` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_address2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_zip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_tags` mediumtext COLLATE utf8_unicode_ci,
  `sl_description` mediumtext COLLATE utf8_unicode_ci,
  `sl_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_hours` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_private` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sl_neat_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`sl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
TRUNCATE TABLE `wptz_store_locator`;
 
INSERT INTO `wptz_store_locator` VALUES ('1', 'Church of Christ', '4000 W ', '', 'Las Vegas', '', '', 'NV 89102', '36.1563457', '-115.2018844', '', '', 'http://circulocristiano.com/', '', '', '', '', '', '', '');
# --------------------------------------------------------

