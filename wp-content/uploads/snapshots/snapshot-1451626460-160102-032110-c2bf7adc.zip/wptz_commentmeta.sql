CREATE TABLE IF NOT EXISTS `wptz_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wptz_commentmeta`;
 
INSERT INTO `wptz_commentmeta` VALUES ('1', '3', 'akismet_result', 'false'); 
INSERT INTO `wptz_commentmeta` VALUES ('2', '3', 'akismet_history', 'a:3:{s:4:"time";d:1450903123.6918680667877197265625;s:5:"event";s:9:"check-ham";s:4:"user";s:16:"franklinmercedes";}'); 
INSERT INTO `wptz_commentmeta` VALUES ('3', '3', 'akismet_as_submitted', 'a:12:{s:14:"comment_author";s:17:"Franklin Mercedes";s:20:"comment_author_email";s:29:"franklin@circuloCristiano.com";s:18:"comment_author_url";s:0:"";s:15:"comment_content";s:83:"Where does this comment go to? Is this in response to the library-picture attached?";s:12:"comment_type";s:0:"";s:7:"user_id";s:1:"6";s:7:"user_ip";s:12:"162.17.126.1";s:10:"user_agent";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36";s:4:"blog";s:27:"http://circulocristiano.com";s:9:"blog_lang";s:5:"en_US";s:12:"blog_charset";s:5:"UTF-8";s:9:"permalink";s:57:"http://circulocristiano.com/circulocristiano_icon150x150/";}'); 
INSERT INTO `wptz_commentmeta` VALUES ('4', '4', 'akismet_result', 'false'); 
INSERT INTO `wptz_commentmeta` VALUES ('5', '4', 'akismet_history', 'a:3:{s:4:"time";d:1450904240.142508029937744140625;s:5:"event";s:9:"check-ham";s:4:"user";s:16:"franklinmercedes";}'); 
INSERT INTO `wptz_commentmeta` VALUES ('6', '4', 'akismet_as_submitted', 'a:13:{s:14:"comment_author";s:17:"Franklin Mercedes";s:20:"comment_author_email";s:29:"franklin@circuloCristiano.com";s:18:"comment_author_url";s:0:"";s:15:"comment_content";s:39:"This comment area is for what section??";s:12:"comment_type";s:0:"";s:7:"user_ID";i:6;s:7:"user_id";i:6;s:7:"user_ip";s:12:"162.17.126.1";s:10:"user_agent";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36";s:4:"blog";s:27:"http://circulocristiano.com";s:9:"blog_lang";s:5:"en_US";s:12:"blog_charset";s:5:"UTF-8";s:9:"permalink";s:71:"http://circulocristiano.com/events/2015/12/cc-and-rvc-change-the-world/";}'); 
INSERT INTO `wptz_commentmeta` VALUES ('7', '3', 'akismet_history', 'a:3:{s:4:"time";d:1451256490.4183409214019775390625;s:5:"event";s:15:"status-approved";s:4:"user";s:9:"admin@scb";}'); 
INSERT INTO `wptz_commentmeta` VALUES ('8', '6', 'akismet_result', 'false'); 
INSERT INTO `wptz_commentmeta` VALUES ('9', '6', 'akismet_history', 'a:3:{s:4:"time";d:1451256490.6701200008392333984375;s:5:"event";s:9:"check-ham";s:4:"user";s:9:"admin@scb";}'); 
INSERT INTO `wptz_commentmeta` VALUES ('10', '6', 'akismet_as_submitted', 'a:13:{s:14:"comment_author";s:9:"admin@scb";s:20:"comment_author_email";s:29:"scottb50@circulocristiano.com";s:18:"comment_author_url";s:0:"";s:15:"comment_content";s:6:"it is.";s:12:"comment_type";s:0:"";s:7:"user_ID";i:1;s:7:"user_id";i:1;s:7:"user_ip";s:13:"72.193.90.170";s:10:"user_agent";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36";s:4:"blog";s:27:"http://circulocristiano.com";s:9:"blog_lang";s:5:"en_US";s:12:"blog_charset";s:5:"UTF-8";s:9:"permalink";s:57:"http://circulocristiano.com/circulocristiano_icon150x150/";}');
# --------------------------------------------------------

