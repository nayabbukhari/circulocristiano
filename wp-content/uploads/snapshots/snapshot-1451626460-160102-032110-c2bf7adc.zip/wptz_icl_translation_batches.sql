CREATE TABLE IF NOT EXISTS `wptz_icl_translation_batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tp_id` int(11) DEFAULT NULL,
  `ts_url` text COLLATE utf8mb4_unicode_ci,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wptz_icl_translation_batches`;
 
INSERT INTO `wptz_icl_translation_batches` VALUES ('1', 'Manual Translations from December the 17th, 2015', '', '', '2015-12-17 20:06:37'); 
INSERT INTO `wptz_icl_translation_batches` VALUES ('2', 'Manual Translations from December the 18th, 2015', '', '', '2015-12-18 00:08:43');
# --------------------------------------------------------

