<?php return array (
  'title' => 'Get in Touch',
  'elements' =>
  array (
    0 =>
    array (
      'elType' => 'section',
      'title' => 'Get in Touch',
      'elements' =>
      array (
        0 =>
        array (
          'title' => 'Row 1',
          'elType' => 'row',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Get in Touch',
                  'level' => 'h2',
                  'looks_like' => 'h3',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '4px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">We always love to hear from our customers. Feel free to drop in or contact us during our business hours.</p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '5%',
            2 => '0px',
            3 => '5%',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'center-text',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        1 =>
        array (
          'elType' => 'row',
          'title' => 'Row 2',
          'columnLayout' => '1/2 + 1/2',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Hours',
                  'level' => 'h3',
                  'looks_like' => 'h4',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '5px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Monday – Friday <span class="right"><strong>6am – 10pm</strong></span></p>
<p class="man">Saturday <span class="right"><strong>4am – 12pm</strong></span></p>
<p class="man">Sunday <span class="right"><strong>8am – 9pm</strong></span></p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                3 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '45px',
                  'visibility' =>
                  array (
                    0 => 'x-hide-xl',
                    1 => 'x-hide-lg',
                    2 => 'x-hide-md',
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => true,
              'size' => '1/2',
              'title' => '1/2',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'custom-headline',
                  'content' => 'Contact',
                  'level' => 'h3',
                  'looks_like' => 'h4',
                  'accent' => false,
                  'type' => 'left',
                  'custom_id' => '',
                  'class' => 'man',
                  'style' => '',
                  'title' => 'Copy of undefined',
                  'text_align' => 'none',
                ),
                1 =>
                array (
                  'elType' => 'gap',
                  'gap_size' => '5px',
                  'visibility' =>
                  array (
                  ),
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                ),
                2 =>
                array (
                  'elType' => 'text',
                  'content' => '<p class="man">Address <span class="right"><strong>555 Business Lane</strong></span></p>
<p class="man">Phone <span class="right"><strong>555.555.1234</strong></span></p>
<p class="man">Email <span class="right"><strong>contact@yourdomain.com</strong></span></p>',
                  'text_align' => 'none',
                  'custom_id' => '',
                  'class' => '',
                  'style' => '',
                  'title' => 'Copy of undefined',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => true,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '45px',
            1 => 'auto',
            2 => '45px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
        2 =>
        array (
          'elType' => 'row',
          'title' => 'Row 3',
          'columnLayout' => '1/1',

          'elements' =>
          array (
            0 =>
            array (
              'active' => true,
              'elType' => 'column',
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'elements' =>
              array (
                0 =>
                array (
                  'elType' => 'google-map',
                  'childType' => 'google-map-marker',
                  'lat' => '37.8067572',
                  'lng' => '-122.4161852',
                  'zoom' => '17',
                  'zoom_control' => false,
                  'drag' => false,
                  'height' => '400px',
                  'hue' => '',
                  'no_container' => true,
                  'class' => 'man',
                  'style' => '',
                  'elements' =>
                  array (
                    0 =>
                    array (
                      'elType' => 'google-map-marker',
                      'title' => 'Beach St.',
                      'lat' => '37.806688',
                      'lng' => '-122.419036',
                      'info' => '',
                      'image' => '',
                    ),
                    1 =>
                    array (
                      'elType' => 'google-map-marker',
                      'title' => 'Taylor St.',
                      'lat' => '37.806463',
                      'lng' => '-122.415812',
                      'info' => '',
                      'image' => '',
                    ),
                    2 =>
                    array (
                      'elType' => 'google-map-marker',
                      'title' => 'Mason St.',
                      'lat' => '37.806578',
                      'lng' => '-122.414230',
                      'info' => '',
                      'image' => '',
                    ),
                  ),
                  'custom_id' => '',
                ),
              ),
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            1 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            2 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            3 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            4 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
            5 =>
            array (
              'elType' => 'column',
              'active' => false,
              'size' => '1/1',
              'title' => '1/1',
              'childType' => 'any',
              'element_info' => false,
              'fade' => false,
              'fade_animation' => 'in',
              'fade_animation_offset' => '45px',
              'text_align' => 'none',
              'custom_id' => '',
              'class' => '',
              'style' => '',
              'bg_color' => '',
              'padding' =>
              array (
                0 => '0px',
                1 => '0px',
                2 => '0px',
                3 => '0px',
                4 => 'linked',
              ),
              'border_style' => 'none',
              'border_color' => '',
              'border' =>
              array (
                0 => '1px',
                1 => '1px',
                2 => '1px',
                3 => '1px',
                4 => 'linked',
              ),
            ),
          ),
          'childType' => 'column',
          'inner_container' => false,
          'marginless_columns' => false,
          'margin' =>
          array (
            0 => '0px',
            1 => 'auto',
            2 => '0px',
            3 => 'auto',
            4 => 'unlinked',
          ),
          'padding' =>
          array (
            0 => '0px',
            1 => '0px',
            2 => '0px',
            3 => '0px',
            4 => 'unlinked',
          ),
          'border_style' => 'none',
          'border_color' => '',
          'border' =>
          array (
            0 => '1px',
            1 => '1px',
            2 => '1px',
            3 => '1px',
            4 => 'linked',
          ),
          'text_align' => 'none',
          'visibility' =>
          array (
          ),
          'custom_id' => '',
          'class' => '',
          'style' => '',
          'bg_color' => '',
        ),
      ),
      'childType' => 'row',
      'bg_type' => 'color',
      'bg_color' => '#ffffff',
      'bg_image' => '',
      'bg_pattern_toggle' => false,
      'parallax' => false,
      'bg_video' => '',
      'bg_video_poster' => '',
      'margin' =>
      array (
        0 => '0px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'padding' =>
      array (
        0 => '45px',
        1 => '0px',
        2 => '0px',
        3 => '0px',
        4 => 'unlinked',
      ),
      'border_style' => 'none',
      'border_color' => '',
      'border' =>
      array (
        0 => '1px',
        1 => '1px',
        2 => '1px',
        3 => '1px',
        4 => 'linked',
      ),
      'text_align' => 'none',
      'visibility' =>
      array (
      ),
      'custom_id' => '',
      'class' => '',
      'style' => '',
    ),
  ),
);