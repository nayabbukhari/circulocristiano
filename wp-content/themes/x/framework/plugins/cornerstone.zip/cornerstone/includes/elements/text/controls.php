<?php

/**
 * Element Controls: Text
 */

return array(

	'common' => array( 'text_align' ),

	'content' => array(
		'type'    => 'editor',
		'context' => 'content',
	),

);